made by AriesWu◎
This is a free app,
It is a Calculator in the Cumputor.